// src/pages/LoginPage.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { currentUser, login, signup, logout } = useAuth();
  const navigate = useNavigate();

  // ✅ Redirect logged-in users to /cart
  useEffect(() => {
    if (currentUser) {
      navigate("/cart");
    }
  }, [currentUser, navigate]);

  const handleSubmit = async (e) => {
  e.preventDefault();
  console.log("Login/Signup form submitted"); // Add this

  try {
    if (isLogin) {
      await login(email, password);
    } else {
      await signup(email, password);
    }
    navigate("/dashboard");
  } catch (error) {
    alert(`${isLogin ? "Login" : "Signup"} failed: ` + error.message);
  }
};


  return (
    <div className="min-h-screen flex">
      <div className="w-1/2 hidden md:block">
        <img
          src="https://source.unsplash.com/800x600/?jaggery,sweets"
          alt="Visual"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="w-full md:w-1/2 flex items-center justify-center p-8 bg-yellow-50">
        <form onSubmit={handleSubmit} className="w-full max-w-md space-y-6">
          <h2 className="text-3xl font-bold text-yellow-800">
            {isLogin ? "Welcome Back" : "Create Account"}
          </h2>

          <input
            type="email"
            placeholder="Email"
            className="w-full p-3 border rounded-xl outline-none"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-3 border rounded-xl outline-none"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button
            type="submit"
            className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-semibold p-3 rounded-xl"
          >
            {isLogin ? "Login" : "Sign Up"}
          </button>

          <p className="text-sm text-center">
            {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-yellow-700 underline"
            >
              {isLogin ? "Sign up" : "Login"}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}
